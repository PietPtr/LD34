LUNAR LANDING

A way oversimplified simulator for the Apollo program. 

Control the Lunar Lander with two controls: The left and Right Arrow key.
Pay attention to your instruments! Warning signs indicate wether your velocity 
is low enough to attempt a landing and your attitude, altitude, and thrust are
all displayed on screen.

Installation:
- Install the sfml library using your package manager or from this site: http://www.sfml-dev.org/download/sfml/2.3.2/ 
- Run LunarLanding
