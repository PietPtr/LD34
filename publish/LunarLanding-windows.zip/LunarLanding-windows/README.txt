LUNAR LANDING

A way oversimplified simulator for the Apollo program. 

Control the Lunar Lander with two controls: The left and Right Arrow key.
Pay attention to your instruments! Warning signs indicate wether your velocity 
is low enough to attempt a landing and your attitude, altitude, and thrust are
all displayed on screen.

Installation:
- Run LunarLanding.exe
